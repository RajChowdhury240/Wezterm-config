local config = require "config"
local keybindings = require "keys"

config.keys = keybindings

return config
